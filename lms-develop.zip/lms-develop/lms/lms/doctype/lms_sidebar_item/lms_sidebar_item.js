// Copyright (c) 2024, Frappe and contributors
// For license information, please see license.txt

// frappe.ui.form.on("LMS Sidebar Item", {
// 	refresh(frm) {

// 	},
// });
