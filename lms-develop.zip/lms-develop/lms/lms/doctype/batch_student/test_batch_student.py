# Copyright (c) 2022, Frappe and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestBatchStudent(FrappeTestCase):
	pass
