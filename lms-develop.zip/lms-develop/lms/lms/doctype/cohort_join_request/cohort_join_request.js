// Copyright (c) 2021, FOSS United and contributors
// For license information, please see license.txt

frappe.ui.form.on("Cohort Join Request", {
	// refresh: function(frm) {
	// }
});
