import frappe
from lms.install import add_pages_to_nav


def execute():
	add_pages_to_nav()
