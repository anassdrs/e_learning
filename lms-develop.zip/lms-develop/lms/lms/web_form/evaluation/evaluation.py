import frappe
from frappe import _


def get_context(context):
	pass
